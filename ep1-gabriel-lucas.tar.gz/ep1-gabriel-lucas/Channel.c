/* Internal headers */
#include "Channel.h"
