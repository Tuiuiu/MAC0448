#ifndef _WEATHER_H
#define _WEATHER_H

int get_weather (int connfd);

#endif /* _WEATHER_H */